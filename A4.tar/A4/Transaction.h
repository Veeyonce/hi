#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
#include <cstdlib>
using namespace std;
#include "defs.h"

class Transaction
{
  public:
    Transaction(int =0, float=0.0, TransType=DEPOSIT, TransState=FAIL);
    ~Transaction();
    int		        getID();
    float		    getAmount();
    string		    getDate();
    TransType		getType();
    TransState		getState();
    int             getAcctNum();

    void            setDate(string d);

  private:
    static int nextTransID;
    int         acctNum;
    int			transID;
    string		transDate;
    float		amount;
    TransType   transType;
    TransState  transState;
    
};

#endif