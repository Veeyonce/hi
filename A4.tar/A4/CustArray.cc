#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;
#include "CustArray.h"

CustArray::CustArray()
{
  currentSize = 0;
}

CustArray::~CustArray(){
	for(int i = 0; i < currentSize; i++){
		delete elements[i];
	}
}

int CustArray::getSize() { return currentSize; }

Customer* CustArray::get(int index)
{
  if (index < 0 || index >= currentSize)
    cout << "List is empty" << endl;
  return elements[index];
}

void CustArray::add(Customer* custom)
{
  if (currentSize >= MAX_ARR)
    return;

  elements[currentSize++] = custom;
}

bool CustArray::checkID(int id){
	bool check = false;
	for(int i = 0; i < currentSize; i++){
		if (id == elements[i]->uniqueID){
			check = true;
		}
	}
	return check;
}