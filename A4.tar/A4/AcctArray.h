/* * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                 */
/*  Program:  Simple Banking System                */
/*  Author:   Christine Laurendeau                 */
/*  Date:     08-JUN-2016                          */
/*                                                 */
/*  (c) 2016 Christine Laurendeau                  */
/*  All rights reserved.  Distribution and         */
/*  reposting, in part or in whole, without the    */
/*  written consent of the author, is illegal.     */
/*                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef ACCTARRAY_H
#define ACCTARRAY_H

#include "defs.h"
#include "Account.h"
#include <string>
#include <cstdlib>
using namespace std;


class AcctArray
{
  public:
    AcctArray();
    ~AcctArray();
    void add(Account*);
    Account* get(int);
    int getSize();

    bool checkNum(int); // added for checking for account nums
  private:
    Account* elements[MAX_ARR];
    int size;
};

#endif

