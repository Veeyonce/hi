/* * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                 */
/*  Program:  Simple Banking System                */
/*  Author:   Christine Laurendeau                 */
/*  Date:     08-JUN-2016                          */
/*                                                 */
/*  (c) 2016 Christine Laurendeau                  */
/*  All rights reserved.  Distribution and         */
/*  reposting, in part or in whole, without the    */
/*  written consent of the author, is illegal.     */
/*                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef ACCOUNT_H
#define ACCOUNT_H

#include "defs.h"

class Account
{
  public:
    Account(int=0, AcctType=GENERAL);
    ~Account();
    AcctType   getAcctType();
    int        getAcctNum();
    int        getCust();
    float      getBalance();
  protected:
    static int nextAcctNum;
    AcctType   acctType;
    int        acctNum;
    int        cust;
    float      balance;
};

#endif
