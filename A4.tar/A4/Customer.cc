#include "defs.h"
#include "Customer.h"


Customer::Customer(int id, string n) 
{ 
  uniqueID = id;
  name     = n;
}

Customer::~Customer(){}

int      Customer::getUniqueID()  { return uniqueID; }
string      Customer::getName()     { return name; }