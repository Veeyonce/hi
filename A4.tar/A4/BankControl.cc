/* * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                 */
/*  Program:  Simple Banking System                */
/*  Author:   Christine Laurendeau                 */
/*  Date:     08-JUN-2016                          */
/*                                                 */
/*  (c) 2016 Christine Laurendeau                  */
/*  All rights reserved.  Distribution and         */
/*  reposting, in part or in whole, without the    */
/*  written consent of the author, is illegal.     */
/*                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * */

#include "BankControl.h"
#include "Account.h"
#include "Customer.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

BankControl::BankControl()
{
  init();
}

BankControl::~BankControl(){
}

void BankControl::launch()
{
  int choice;

  while (1) {
    choice = -1;
    view.mainMenu(choice);
    if (choice == 1) {		// Admin menu
      processAdmin();
    }
    else if (choice == 2) {	// Customer menu
      processCust();
    }
    else {
      break;
    }
  }
}

void BankControl::processAdmin()
{
  int      choice;
  int      custId;
  AcctType acctType;

  while (1) {
    choice = -1;
    view.adminMenu(choice);
    if (choice == 1) {		// add account
      view.readCustId(custId,bank);
      view.readAcctType(acctType);
      Account* acct = new Account(custId, acctType);
      bank.addAcct(acct);
      view.pause();
      delete acct;
    }
    else if (choice == 2) {	// print accounts
      view.printAccounts(bank);
      view.pause();
    }
    else if (choice == 3){ //print customers
    	view.printCustomers(bank);
    	view.pause();
    }
    else if (choice == 4){
      TransArray* temp = new TransArray();
      transControl.retrieve(*temp);
      view.pause();
      delete temp;
    }
    else {
      break;
    }
  }
}

void BankControl::processCust()
{
  int choice, accNum;
  string str;
  TransType transType;
  float amount;
  TransState transState;
  int type;

  while (1) {
    choice = 0;
    view.custMenu(choice);
    if (choice == 1) {	// check balance
        cout << "Enter account number you want to check: ";
        getline(cin, str);
        stringstream ss(str);
        ss >> accNum;
        //cout << bank.getAccounts()->checkNum(accNum) << accNum << endl;
        for (int i = 0; i < bank.getAccounts()->getSize(); i++){

          Account* acct = bank.getAccounts()->get(i);

          if(bank.getAccounts()->checkNum(accNum) == true){
          view.printBalance(acct->getBalance());
          break;
        }
          else {
          cout << "Account number doesn't exist! Returning to Customer Menu.";
          break;
          }
          delete acct;
        }
    }
    if (choice == 2){
        cout << "Enter the account number for the transaction: ";
        getline(cin, str);
        stringstream ss(str);
        ss >> accNum;
        cout << accNum << endl;
        for (int i = 0; i < bank.getAccounts()->getSize(); i++){

          Account* acct = bank.getAccounts()->get(i);

          if(bank.getAccounts()->checkNum(accNum) == true){
          cout << "Enter transaction type." << endl;
          cout << "[0]-DEPOSIT [1]-WITHDRAW [2]-DEBIT [3]-CHEQUE : ";
          getline(cin, str);
          stringstream ss(str);
          ss >> type;
          cout << type << endl;
          if (type == 0){
            transType = DEPOSIT;
          }
          else if(type == 1){
            transType = WITHDRAW;
          }
          else if(type == 2){
            transType = DEBIT;
          }
          else if(type == 3){
            transType = CHEQUE;
          }
          //cout << "TransType: " << transType << endl;
          cout << "Enter amount in $ : ";
          getline(cin, str);
          stringstream ss2(str);
          ss2 >> amount;
          //cout << fixed << setprecision( 2 ) << amount << endl;
          if (amount < 0){
            transState = FAIL;
          }
          else if (acct->getBalance() < amount && transType == 1){
            transState = FAIL;
          }
          else{
            transState = SUCCESS;
          }
          //cout << "State " << transState << endl;

          Transaction* trans = new Transaction(accNum, amount, transType, transState);

          cout << "Transaction created: " /*<< trans*/ << endl;

          transControl.update(trans);
          // TransArray* temp = new TransArray();
          // transControl.retrieve(*temp);

          delete trans;

          break;
        }
          else {
          cout << "Account number doesn't exist! Returning to Customer Menu.";
          break;
          }
          delete acct;
        }
    }
    else {
      break;
    }
  }
}

void BankControl::init()
{
  /*
     This function is so ugly!  It's because we're using 
     statically allocated memory, instead of dynamically
     alloated.  Don't worry, we'll fix this in Assignment #2.
  */
  
  Customer* cust1 = new Customer(1000, "Veronica Drilon");
  bank.addCust(cust1);

  Customer* cust2 = new Customer(1001, "Maria");
  bank.addCust(cust2);


  Account* acc01 = new Account(1000, CHEQUING);
  bank.addAcct(acc01);

  Account* acc02 = new Account(1001, SAVINGS);
  bank.addAcct(acc02);
  Account* acc03 = new Account(1001);
  bank.addAcct(acc03);

  TransControl transControl;

  delete cust1;
  delete cust2;

  delete acc01;
  delete acc02;
  delete acc03;

}

