#include <string>
#include <cstdlib>
using namespace std;
#include "Transaction.h"

int Transaction::nextTransID = 2001;

Transaction::Transaction(int n, float a, TransType t, TransState s){
transID = nextTransID++;
amount = a;
transDate = " ";
transType = t;
transState = s;
acctNum = n;
}

Transaction::~Transaction(){}

int Transaction::getID(){return transID;}
float Transaction::getAmount(){return amount;}
string Transaction::getDate(){return transDate;}
TransType Transaction::getType(){return transType;}
TransState Transaction::getState(){return transState;}
int Transaction::getAcctNum(){ return acctNum; }

void Transaction::setDate(string d){
	transDate = d;
}
