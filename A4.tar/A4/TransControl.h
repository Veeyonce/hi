#ifndef TRANSCONTROL_H
#define TRANSCONTROL_H

#include <iomanip>
#include <ctime>
#include <sstream>
using namespace std;
#include "TransControl.h"
#include "TransArray.h"

class TransControl
{
  public:
  	TransControl();
  	~TransControl();
  	void		update(Transaction*);
  	void		retrieve(TransArray&);
  	void 		getTime(string&);
  private:
    TransArray		transactions;
};
#endif
