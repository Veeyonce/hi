/* * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                 */
/*  Program:  Simple Banking System                */
/*  Author:   Christine Laurendeau                 */
/*  Date:     08-JUN-2016                          */
/*                                                 */
/*  (c) 2016 Christine Laurendeau                  */
/*  All rights reserved.  Distribution and         */
/*  reposting, in part or in whole, without the    */
/*  written consent of the author, is illegal.     */
/*                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include "View.h"
using namespace std;

void View::mainMenu(int& choice)
{
  string str;

  choice = -1;

  cout<< "\n\n\n                   BANKING SYSTEM MAIN MENU\n\n";
  cout<< "          1. Admin menu \n\n";
  cout<< "          2. Customer menu \n\n";
  cout<< "          0. Exit\n\n";

  while (choice < 0 || choice > 2) {
    cout << "Enter your selection:  ";
    choice = readInt();
  }
}

void View::adminMenu(int& choice)
{
  string str;

  choice = -1;

  cout<< "\n\n\n                   BANKING SYSTEM ADMIN MENU\n\n";
  cout<< "          1. Add account \n\n";
  cout<< "          2. Print accounts \n\n";
  cout<< "          3. Print customers \n\n";
  cout<< "          4. Print transactions \n\n";
  cout<< "          0. Exit\n\n";

  while (choice < 0 || choice > 4) {
    cout << "Enter your selection:  ";
    choice = readInt();
  }
}

void View::custMenu(int& choice)
{
  string str;

  choice = -1;

  cout<< "\n\n\n                   BANKING SYSTEM CUSTOMER MENU\n\n";
  cout<< "          1. Check balance \n\n";
  cout<< "          2. Make a transaction \n\n";
  cout<< "          0. Exit\n\n";

  while (choice < 0 || choice > 2) {
    cout << "Enter your selection:  ";
    choice = readInt();
  }
}

void View::printAccounts(Bank& bank) //printing accounts
{
  // The stringstream class helps us convert from numeric values to string.
  // The I/O manipulation functions help us make the output look pretty.

  stringstream ss;

  cout << endl << "ACCOUNTS: " << endl;

  for (int i=0; i<bank.getAccounts()->getSize(); i++) {

    Account* acct = bank.getAccounts()->get(i);

    if (acct->getAcctType() == CHEQUING)
      cout << left << setw(15)<< setfill(' ') <<"Chequing:  ";
    else if (acct->getAcctType() == SAVINGS)
      cout << left << setw(15)<< setfill(' ') <<"Savings:   ";	
    else
      cout << left << setw(15)<< setfill(' ') << "General:   ";

    cout << left << setw(10) << setfill(' ') << acct->getAcctNum();

    for(int j = 0; j < bank.getCustomers()->getSize(); j++){
    	Customer* cust = bank.getCustomers()->get(j);
    	if (bank.getAccounts()->get(i)->getCust() == cust->getUniqueID()){
    		cout << left << setw(15) << setfill(' ') << cust->getName();
    	}
    }
    cout << right << setw(10) << setfill(' ') << "$ " << acct->getBalance() << endl;

  }
}

void View::printCustomers(Bank& bank) { //printing customers
	stringstream ss2;

  cout << endl << "CUSTOMERS: " << endl;

  for (int i=0; i<bank.getCustomers()->getSize(); i++) {

    Customer* cust = bank.getCustomers()->get(i);

    cout << left << setw(25) << setfill('.') << cust->getName() << " " << left << setw(13) << setfill('-') << cust->getUniqueID() 
    	<< left << setw(19) << setfill(' ') << "Account(s):" << endl;

	    for (int i=0; i<bank.getAccounts()->getSize(); i++) {

	    Account* acct = bank.getAccounts()->get(i);

		    if (bank.getAccounts()->get(i)->getCust() == cust->getUniqueID()){
		    	if (acct->getAcctType() == CHEQUING){
		    		cout << right << setw(58) << setfill(' ') << "Chequing";
		    	}
		    	else if (acct->getAcctType() == SAVINGS){
		    		cout << right << setw(57) << setfill(' ') << "Savings";
		    	}
		    	else {
		    		cout << right << setw(57) << setfill(' ') << "General";
		    	}
		    	cout << "" << endl;
		    }
	   	}
    }
}

void View::readCustId(int& id, Bank& bank)
{
	string str;
	bool ask = true;
	int check;
	while(ask != false){
		cout << "Customer id: ";
  		getline(cin, str);
  		stringstream ss(str);
  		ss >> check;
  		cout << bank.getCustomers()->checkID(check) << check << endl;
		if (bank.getCustomers()->checkID(check) == true){
			ask = false;
		}
		else{
			cout << "Enter an existing Customer ID!" << endl;
			ask = true;
		}
		
	}
	stringstream ss(str);
	ss >> id;
}

void View::printBalance(float b)
{
  // The stringstream class helps us convert from numeric values to string.
  // The I/O manipulation functions help us make the output look pretty.

  stringstream ss;
  ss << setw(8) << fixed << setprecision(2) << b;
  cout << endl << "Your balance is $" << ss.str() << endl << " -- press enter to continue...";
  cin.get();
}

void View::printError(string err)
{
  cout << endl << err << " -- press enter to continue...";
  cin.get();
}

void View::readAcctType(AcctType& acctType)
{
  string str;
  int    num;

  cout << "Account type [1 for chequing, 2 for savings]: ";
  getline(cin, str);
  stringstream ss(str);
  ss >> num;

  if (num == 1)
    acctType = CHEQUING;
  else if (num == 2)
    acctType = SAVINGS;
  else
    acctType = GENERAL;
}

int View::readInt()
{
  string str;
  int    num;

  getline(cin, str);
  stringstream ss(str);
  ss >> num;

  return num;
}

void View::pause()
{
  string str;

  cout << endl << "\nPress enter to continue...";
  getline(cin, str);
}


