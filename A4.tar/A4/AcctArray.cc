/* * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                 */
/*  Program:  Simple Banking System                */
/*  Author:   Christine Laurendeau                 */
/*  Date:     08-JUN-2016                          */
/*                                                 */
/*  (c) 2016 Christine Laurendeau                  */
/*  All rights reserved.  Distribution and         */
/*  reposting, in part or in whole, without the    */
/*  written consent of the author, is illegal.     */
/*                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * */

#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;
#include "AcctArray.h"

AcctArray::AcctArray()
{
  size = 0;
}

AcctArray::~AcctArray(){
	for(int i = 0; i < size; i++){
		delete elements[i];
	}
}

int AcctArray::getSize() { return size; }

Account* AcctArray::get(int index)
{
  if (index < 0 || index >= size){
    cout << "List is empty" << endl;
}
  return elements[index];
}

void AcctArray::add(Account* cust)
{
  if (size >= MAX_ARR)
    return;

  elements[size++] = cust;
}

bool AcctArray::checkNum(int id){
	bool check = false;
	for(int i = 0; i < size; i++){
		if (id == elements[i]->getAcctNum()){
			check = true;
		}
	}
	return check;
}

