#include <iomanip>
#include <ctime>
#include <sstream>
#include <string>
#include <iostream>
using namespace std;
#include "TransArray.h"

TransArray::TransArray(){
	size = 0;
}

TransArray::~TransArray(){
	for(int i = 0; i < size; i++){
		delete myTransactions[i];
	}
}

int TransArray::getSize(){ return size; }

void TransArray::add(Transaction* trans){

	if (size >= MAX_ARR)
    	return;

	myTransactions[size++] = trans;
}

Transaction* TransArray::get(int index){
	if (index < 0 || index >=size)
		cout << "List is empty" << endl;
	return myTransactions[index];
}