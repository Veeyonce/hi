#ifndef TRANSARRAY_H
#define TRANSARRAY_H

#include "Transaction.h"
#include "defs.h"

class TransArray
{
  public:
  	TransArray();
	~TransArray();
  	void			add(Transaction*);
  	int				getSize();
  	Transaction*	get(int);
  private:
    Transaction*    myTransactions[MAX_ARR];
    int				size;
};
#endif
