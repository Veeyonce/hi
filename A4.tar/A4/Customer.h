#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "defs.h"
#include <string>
using namespace std;

class Customer
{
  public:
    Customer(int = 0, string = "");
    ~Customer();
    int getUniqueID();
    string getName();

    int uniqueID;
    string name;
};

#endif